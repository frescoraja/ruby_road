def caesar_cipher(str, shift)
	words = str.split(" ")
	offset = 0
	words.each do |word|
		for i in 0...word.length
			offset = shift + word[i].ord
			if offset > 122
				offset = (offset % 122 ) + 96
			end
			word[i] = offset.chr 
		end
	end
	return words.join(" ")
end
