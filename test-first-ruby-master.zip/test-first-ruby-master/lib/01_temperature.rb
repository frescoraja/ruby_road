def ftoc(temp_c)
    p (temp_c - 32.0) * 5.0 / 9.0
end

def ctof(temp_f)
    p (temp_f * 9.0 / 5.0) + 32.0
end