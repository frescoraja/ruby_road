def add(num1,num2)
    num1 + num2
end

def subtract(num1,num2)
    num1 - num2
end
def sum(nums)
    nums.reduce(0,:+)
    
    ## answer = 0
    ## nums.each { |x| answer += x}
    ## return answer
end
def multiply(nums)
    nums.reduce(1,:*)
    
    ## answer = 1
    ## nums.each { |x| answer *= x }
    ## return answer
end
def power(num,exp)
    num ** exp
end

def factorial(num)
    if num == 0
        return 1
    else
        num * factorial(num-1)

    end
end